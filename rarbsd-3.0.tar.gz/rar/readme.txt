                        The RAR Archiver

   RAR features:

 o RAR introduces a NEW and original compression algorithm.  It
   allows higher compression ratios than other PC archiving tools,
   especially on executable files, Object libraries, large text
   files, etc.

 o RAR offers a NEW, optional, compression algorithm highly optimized
   for multimedia data.

 o RAR provides functionality for creating a 'solid' archive, which
   can raise the compression ratio by 10% - 50% over more common
   methods, particularly when packing large numbers of small files.

 o RAR offers the ability to create and change SFX archives using
   default and external SFX modules.

 o RAR offers the ability to create a multi-volume archive as SFX.

 o RAR offers a number of service functions, such as setting a
   password, adding archive and file comments.  Even physically
   damaged archives may be repaired and an archive may be locked
   to prevent further changes.  Authenticity information may be
   added for additional security and RAR will store information
   on the last update and name of the archive.
